<?php

$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection, 'geo');

if($_POST)
{

    $Cor = $_POST['Cor'];
    $Codigo = $_POST['Codigo'];
    $Marca = $_POST['Marca'];
    $Prefixo = $_POST['Prefixo'];
    $Modelo = $_POST['Modelo'];
    $Reserva_padrao = $_POST['Reserva_padrao'];
    $Nivel_padrao = $_POST['Nivel_padrao'];
    $Template_padrao = $_POST['Template_padrao'];
    $Descricao = $_POST['Descricao'];
    $Implantada = $_POST['Implantada'];
    $Nao_implantada = $_POST['Nao_implantada'];
    $Em_projeto = $_POST['Em_projeto'];
 
    //$securePass = md5($Permitir_venda);


    $query = "INSERT INTO caixa (Cor, Codigo, Marca, Modelo, Prefixo, Reserva_padrao, Nivel_padrao, Template_padrao, Descricao, Implantada, Nao_implantada, Em_projeto) VALUES ('$Cor', '$Codigo', '$Marca', '$Modelo', '$Prefixo','$Reserva_padrao','$Nivel_padrao', '$Template_padrao', '$Descricao', '$Implantada', '$Nao_implantada', '$Em_projeto');";
    $query_run = mysqli_query($connection, $query);

    if($query_run){
        echo "<script>alert('Registado com sucesso!')</script>";
        header('Location:http://localhost/admin/views/caixa.php');
       
    }else{
        echo "<script>alert('Erro projeto já existe!')</script>";
    }
}

?>