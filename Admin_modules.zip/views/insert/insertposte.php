<?php

$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection, 'geo');

if($_POST)
{

    if(isset($_POST['Permitir_venda'])){

        $Permitir_venda = $_POST['Permitir_venda'] = "Sim";

    }else{

        $Permitir_venda = "Não";

    }

    $Cor = $_POST['Cor'];
    $Nome = $_POST['Nome'];
    $Prefixo = $_POST['Prefixo'];
    $Observacoes = $_POST['Observacoes'];
 
    //$securePass = md5($Permitir_venda);

    

    $query = "INSERT INTO poste (Cor, Nome, Prefixo, Permitir_venda, Observacoes) VALUES ('$Cor', '$Nome', '$Prefixo','$Permitir_venda','$Observacoes');";
    $query_run = mysqli_query($connection, $query);

    if($query_run){
        echo "<script>alert('Registado com sucesso!')</script>";
        header('Location:http://localhost/admin/views/poste.php');
       
    }else{
        echo "<script>alert('Erro projeto já existe!')</script>";
    }
}

?>