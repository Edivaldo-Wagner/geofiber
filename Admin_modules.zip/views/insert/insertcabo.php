<?php

$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection, 'geo');

if($_POST)
{

    $Codigo = $_POST['Codigo'];
    $Marca = $_POST['Marca'];
    $Modelo = $_POST['Modelo'];
    $Nivel_padrao = $_POST['Nivel_padrao'];
    $Numero_de_looses = $_POST['Numero_de_looses'];
    $Numero_de_fibras = $_POST['Numero_de_fibras'];
    $Fibras_por_looses = $_POST['Fibras_por_looses'];
    $Atenuacao = $_POST['Atenuacao'];
    $Perfil_de_fibra = $_POST['Perfil_de_fibra'];
    $Descricao = $_POST['Descricao'];
    $Cor_cabo_implantado = $_POST['Cor_cabo_implantado'];
    $Espessura_cabo_implantado = $_POST['Espessura_cabo_implantado'];
    $Cor_cabo_nao_implantado = $_POST['Cor_cabo_nao_implantado'];
    $Espessura_cabo_nao_implantado = $_POST['Espessura_cabo_nao_implantado'];

    //$securePass = md5($Permitir_venda);

    $query = "INSERT INTO cabo (Codigo, Nr_fibras, Nr_looses, Atenuacao, Perfil_fibra, Fibras_por_loose, Descricao, Marca, Modelo, Nivel_padrao, Cor_cabo_implantado, Espessura_cabo_implantado, Cor_cabo_nao_implantado, Espessura_cabo_nao_implantado) VALUES ('$Codigo', '$Numero_de_fibras', '$Numero_de_looses', '$Atenuacao', '$Perfil_de_fibra', '$Fibras_por_looses', '$Descricao', '$Marca', '$Modelo', '$Nivel_padrao', '$Cor_cabo_implantado', '$Espessura_cabo_implantado', '$Cor_cabo_nao_implantado', '$Espessura_cabo_nao_implantado');";
    $query_run = mysqli_query($connection, $query);

    if($query_run){
        echo "<script>alert('Registado com sucesso!')</script>";
        header('Location:http://localhost/admin/views/cabo.php');
       
    }else{
        echo "<script>alert('Erro projeto já existe!')</script>";
    }
}

?>