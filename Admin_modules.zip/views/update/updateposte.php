<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection, 'geo');

if(isset($_POST['updatedata']))//updatedata
    {   

        if(isset($_POST['Permitir_venda'])){

        $Permitir_venda = $_POST['Permitir_venda'] = "Sim";

    }else{

        $Permitir_venda = "Não";

    }


        $id = $_POST['update_id'];
        
        $Cor = $_POST['Cor'];
        $Nome = $_POST['Nome'];
        $Prefixo = $_POST['Prefixo'];
        $Observacoes = $_POST['Observacoes'];
  

        $query = "UPDATE poste SET Cor='$Cor', Nome='$Nome', Prefixo='$Prefixo', Permitir_venda=' $Permitir_venda' , Observacoes=' $Observacoes'  WHERE id='$id'  ";
        $query_run = mysqli_query($connection, $query);

        if($query_run)
        {
            echo '<script> alert("Data Updated"); </script>';
            header('Location:http://localhost/admin/views/poste.php');
        }
        else
        {
            echo '<script> alert("Data Not Updated"); </script>';
        }
    }
?>