<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection, 'geo');

if(isset($_POST['updatedata']))//updatedata
    {   

        
    $id = $_POST['update_id'];
    $Codigo = $_POST['Codigo'];
    $Marca = $_POST['Marca'];
    $Modelo = $_POST['Modelo'];
    $Nivel_padrao = $_POST['Nivel_padrao'];
    $Numero_de_looses = $_POST['Numero_de_looses'];
    $Numero_de_fibras = $_POST['Numero_de_fibras'];
    $Fibras_por_looses = $_POST['Fibras_por_looses'];
    $Atenuacao = $_POST['Atenuacao'];
    $Perfil_de_fibra = $_POST['Perfil_de_fibra'];
    $Descricao = $_POST['Descricao'];
    $Cor_cabo_implantado = $_POST['Cor_cabo_implantado'];
    $Espessura_cabo_implantado = $_POST['Espessura_cabo_implantado'];
    $Cor_cabo_nao_implantado = $_POST['Cor_cabo_nao_implantado'];
    $Espessura_cabo_nao_implantado = $_POST['Espessura_cabo_nao_implantado'];

        
  

        $query = "UPDATE cabo SET Codigo='$Codigo', Nr_fibras='$Numero_de_fibras', Nr_looses='$Numero_de_looses' , Atenuacao='$Atenuacao', Perfil_fibra='$Perfil_de_fibra', Fibras_por_loose='$Fibras_por_looses', Descricao='$Descricao', Marca='$Marca', Modelo='$Modelo', Nivel_padrao='$Nivel_padrao', Cor_cabo_implantado='$Cor_cabo_implantado', Espessura_cabo_implantado='$Espessura_cabo_implantado', Cor_cabo_nao_implantado='$Cor_cabo_nao_implantado', Espessura_cabo_nao_implantado='$Espessura_cabo_nao_implantado' WHERE id='$id'  ";
        $query_run = mysqli_query($connection, $query);

        if($query_run)
        {
            echo '<script> alert("Data Updated"); </script>';
            header('Location:http://localhost/admin/views/cabo.php');
        }
        else
        {
            echo '<script> alert("Data Not Updated"); </script>';
        }
    }
?>