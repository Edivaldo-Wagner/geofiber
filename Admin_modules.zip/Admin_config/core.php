<?php

session_start();

require_once 'connection.php';

//echo $_SESSION['id'];

//if(!$_SESSION['id']){
   // header('location:http://localhost/agenda/index.php');
//}

?>